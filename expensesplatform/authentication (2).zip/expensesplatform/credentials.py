
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'molato.sekgobela@gmail.com'
EMAIL_HOST_PASSWORD = 'hmmy hkiw lguc yfrx'
EMAIL_USE_TLS = True
DEFAULT_FROM_EMAIL = 'molato.sekgobela@gmail.com'
EMAIL_PORT = 587